
    var config = {
      apiKey: "AIzaSyCL8oBfN3YGEB78qfnNzsnMDBTUjrIn4zc",
      authDomain: "locating-system-7784b.firebaseapp.com",
      databaseURL: "https://locating-system-7784b.firebaseio.com",
      projectId: "locating-system-7784b",
      storageBucket: "locating-system-7784b.appspot.com",
      messagingSenderId: "176179877881"
      };
var dataprev=0;
  //test with firebase
  var element = document.getElementById("graph");
  firebase.initializeApp(config);
  firebase.database().ref().on('value', function(snapshot){
    data = snapshot.val()
    var V=data.y1;
    //var T=data.t;
    console.log(V)
    if (V!=dataprev)
    {
      y.push(data.y1);
      createChart(x, y);
      dataprev=V;
    }
    //console.log(T);
   // x.push(data.t);
    
   
});
function myFunction() {

  firebase.database().ref().on('value', function(snapshot){
    data = snapshot.val()
    var patient=data.patient;
    console.log(patient)
    var db = firebase.database();
    db.ref("patient").set("5");
});
}
var y=[];
  var ynew=[];
  //var x=Array.from(Array(1000).keys());
  var x=Array.from(Array(10000).keys()).map(i => 0 + i *5 );


function createChart(x,y){

var data = [{
  x:x,
  y: y,
  type: 'line',
  
}];

var layout = {
  title: 'signal_monitoring',
  responsive: true,
  //color: '#DF56F1',
  xaxis: {
    //title: 'time',
    showgrid: true,
    zeroline: false
  },
  yaxis: {
    //title: 'volt',
    showline: true
  },
  plot_bgcolor:"black",
  paper_bgcolor:"black",

};
Plotly.newPlot(element, data, layout);
//var dataRetrievedLater = element.data;
//var layoutRetrievedLater = element.layout;
var cnt = 0;
setInterval(function(){
    Plotly.extendTraces(element,data, [0]);
    cnt++;
    if(cnt > 500) {
        Plotly.relayout(element,{
            xaxis: {
                range: [cnt-500,cnt]
            }
        });
    }
},15);
}
