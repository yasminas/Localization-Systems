const config = {
    apiKey: "AIzaSyDUo0tFPDeFvV5WQsEFzChTgMSUsW4snko",
    authDomain: "webconnection-fe262.firebaseapp.com",
    databaseURL: "https://webconnection-fe262.firebaseio.com",
    projectId: "webconnection-fe262",
    storageBucket: "webconnection-fe262.appspot.com",
    messagingSenderId: "542140555489"
  };
var dataprev=0;
  //test with firebase
  var element = document.getElementById("graph");
  firebase.initializeApp(config);
  firebase.database().ref().on('value', function(snapshot){
    data = snapshot.val()
    var V=data.y1;
    //var T=data.t;
    console.log(V)
    if (V!=dataprev)
    {
      y.push(data.y1);
      createChart(x, y);
      dataprev=V;
    }
    //console.log(T);
   // x.push(data.t);
    
   
});
/*function myFunction() {

  firebase.database().ref('posts').on('value', function(snapshot){
    data = snapshot.val()
    var patient=data.patient;
    console.log(patient)

  //document.getElementById("demo").innerHTML = "YOU CLICKED ME!";
  function writeNewPost(aya) {
    // A post entry.
    var postData = {
      patient: aya
    };
  
    // Get a key for a new Post.
    var newPostKey = firebase.database().ref('posts').push().key;
  
    // Write the new post's data simultaneously in the posts list and the user's post list.
    var updates = {};
    updates['/posts/' + newPostKey] = postData;
   // updates['/user-posts/' + uid + '/' + newPostKey] = postData;
  
    return firebase.database().ref().update(updates);
  }
});
}*/
var y=[];
  var ynew=[];
  //var x=Array.from(Array(1000).keys());
  var x=Array.from(Array(10000).keys()).map(i => 0 + i *5 );


function createChart(x,y){

var data = [{
  x:x,
  y: y,
  type: 'line',
  
}];

var layout = {
  title: 'signal_monitoring',
  responsive: true,
  //color: '#DF56F1',
  xaxis: {
    //title: 'time',
    showgrid: true,
    zeroline: false
  },
  yaxis: {
    //title: 'volt',
    showline: true
  },
  plot_bgcolor:"black",
  paper_bgcolor:"black",

};
Plotly.newPlot(element, data, layout);
//var dataRetrievedLater = element.data;
//var layoutRetrievedLater = element.layout;
var cnt = 0;
setInterval(function(){
    Plotly.extendTraces(element,data, [0]);
    cnt++;
    if(cnt > 500) {
        Plotly.relayout(element,{
            xaxis: {
                range: [cnt-500,cnt]
            }
        });
    }
},15);
}
