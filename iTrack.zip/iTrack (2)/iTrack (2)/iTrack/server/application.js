
    var config = {
		apiKey: "AIzaSyCL8oBfN3YGEB78qfnNzsnMDBTUjrIn4zc",
		authDomain: "locating-system-7784b.firebaseapp.com",
		databaseURL: "https://locating-system-7784b.firebaseio.com",
		projectId: "locating-system-7784b",
		storageBucket: "locating-system-7784b.appspot.com",
		messagingSenderId: "176179877881"
	  };
// Initialize your Firebase app
firebase.initializeApp(config);


// Reference to the recommendations object in your Firebase database
var ref = firebase.database().ref()/*.child('parameters')*/;
ref.on("value", function(snapshot) {
    var Data=snapshot.val();
    var x=(Data.X)*1520;
    var y=(Data.Y)*610;
    console.log(Data);
   console.log(x);
   console.log(y);
   if (x<260)
   {
     x=x+260;
   }
   else if((x>260||x==260)&&(x<1260||x==1260))
   {
      x=x;
   }
   else
   {
       x=x-260;
   }
   var width = 15;
   var height = 15;
   var canvas = document.createElement('canvas'); //Create a canvas element
   //Set canvas width/height
   canvas.style.width='100%';
   canvas.style.height='100%';
   //Set canvas drawing area width/height
   canvas.width = window.innerWidth;
   canvas.height = window.innerHeight;
   //Position canvas
   canvas.style.position='absolute';
   canvas.style.left=0;
   canvas.style.top=0;
   canvas.style.zIndex=100000;
   canvas.style.pointerEvents='none'; //Make sure you can click 'through' the canvas
   document.body.appendChild(canvas); //Append canvas to body element
   var context = canvas.getContext('2d');
   //Draw rectangle
   context.rect(x,y, width, height);
   context.fillStyle = 'red';
   context.fill();
   ref.on("value", function(snapshot) {
    var Data=snapshot.val();
   var xnew=(Data.X)*1520;
   var ynew=(Data.Y)*610;
   if ( xnew<260)
   {
    xnew= xnew+260;
   }
   else if(( xnew>260|| xnew==260)&&( xnew<1260|| xnew==1260))
   {
    xnew= xnew;
   }
   else
   {
    xnew= xnew-260;
   }
   if (( x!== xnew)||(y!==ynew))
   {
     //document.location.reload(true);
     
   }
})
   /*document.location.reload(true);
   document.location.reload(false);*/
   
   /*ref.on("child_changed", function(snapshot) {
    var changedPost = snapshot.val();
    var Data=snapshot.val();
    var X=Data.x;
    var Y=Data.y;
    console.log(Data);
   console.log(X);
   console.log(Y);
    //console.log("The updated post title is " + changedPost.title);
  });*/

    /*//delete
   firebase.database().ref().child('parameters/x').remove();
   firebase.database().ref().child('parameters/y').remove();*/
   //update
   /*firebase.database().ref().set(
    { 
        x: null, 
        y:null 
    }
);*/

/*firebase.database().ref('parameters').set(
    { 
        x: X, 
        y:Y 
    }
);*/
});/* function (error) {
   console.log("Error: " + error.code);
   
   //Position parameters used for drawing the rectangle
  //var X=50;
   //var Y=150;
}*/

//});

